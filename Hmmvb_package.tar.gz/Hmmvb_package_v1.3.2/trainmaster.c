/*==========================================================================================*/
/*                                                                                          */
/* Copyright (C) [Dec 2015]-[April 2017] Jia Li, Department of Statistics,                  */
/* The Pennsylvania State University, USA - All Rights Reserved                             */
/*                                                                                          */
/* Unauthorized copying of this file, via any medium is strictly prohibited                 */
/*                                                                                          */
/* Proprietary and CONFIDENTIAL                                                             */
/*                                                                                          */
/* NOTICE: All information contained herein is, and remains the property of The             */
/* Pennsylvania State University. The intellectual and technical concepts                   */
/* contained herein are proprietary to The Pennsylvania State University and may            */
/* be covered by U.S. and Foreign Patents, patents in process, and are protected            */
/* by trade secret or copyright law. Dissemination of this information or                   */
/* reproduction of this material is strictly forbidden unless prior written                 */
/* permission is obtained from Jia Li at The Pennsylvania State University. If              */
/* you obtained this code from other sources, please write to Jia Li.                       */
/*                                                                                          */
/*                                                                                          */
/* The software is a part of the package for                                                */
/* Clustering with Hidden Markov Models on Variable Blocks                                  */
/*                                                                                          */
/* Written by Jia Li <jiali@stat.psu.edu>, April 7, 2017                                    */ 
/*                                                                                          */
/*==========================================================================================*/

#include "hmm.h"
#include <string.h>

void printmanual()
{
  int i;

  fprintf(stdout, "---------------- Usage manual for trainmaster ---------------------\n");
  fprintf(stdout, "To see the usage manual, use trainmaster without any argument.\n\n");
  fprintf(stdout, "Syntax: trainmaster -i [...] -m [...] -b [...] ......\n\n");
  fprintf(stdout, "-i [input data filename]\n");
  fprintf(stdout, "   data file is in a typical ascii matrix format: each row contains variables for one data point,\n");
  fprintf(stdout, "   each column in a row is the value of one variable. \n\n");
  fprintf(stdout, "-m [output model filename], the output model is a binary file\n\n");
  fprintf(stdout, "-b [input variable block structure filename], this is a parameter ascii file that follows strict format\n");
  fprintf(stdout, "   This file specifies variable block structure including partion and ordering. When it is given, the block\n");
  fprintf(stdout, "   structure will not be searched.\n");
  fprintf(stdout, "   If this file is given, the data dimension will be read from the file and does not need command-line\n");
  fprintf(stdout, "   input by the \"-d\" option.\n");
  fprintf(stdout, "   If this file is given, the \"-p\" and \"-o\" options will be ignored.\n\n");
  fprintf(stdout, "-d [data dimension], this has to be specified if \"-b\" option is not given.\n\n");
  fprintf(stdout, "-p [input parameter filename], this is a parameter ascii file that specifies the number of components given\n");
  fprintf(stdout, "   the dimension of a variable block. The same block dimension is assigned with one value of #components.\n");
  fprintf(stdout, "   If not given, the program will choose #components by a fixed scheme.\n\n");
  fprintf(stdout, "-o [input parameter filename], this is an ascii file specifying the order of the variables.\n");
  fprintf(stdout, "   Each ordering of variables is in one line. There can be multiple lines giving multiple ways of ordering.\n");
  fprintf(stdout, "   For data with D dimensions, the variable identification numbers should be 0, 1, ..., D-1. \n");
  fprintf(stdout, "   This file is optional. If not given, the program will generate random permutation of variables.\n\n");
  fprintf(stdout, "-e [floating number], this determines the precision of convergence. It can be skipped and a default value will be used.\n\n");
  fprintf(stdout, "-n [number of permutations], number of permutations to be used when searching for variable block structure.\n");
  fprintf(stdout, "   The default value is 1 or equals the number of permutations given in the \"-o\" option file.\n\n");
  fprintf(stdout, "-x [maximum variable block dimension], the default is 10.\n\n");
  fprintf(stdout, "-y This is a flag. If not flagged, the minimum block dimension is 1 if variable block search is performed. \n");
  fprintf(stdout, "   If flagged, the minimum block dimension is 2.\n\n");
  fprintf(stdout, "-0 This is flag (note: zero, not capital o). If not flagged, k-means initialization will always be performed.\n");
  fprintf(stdout, "   If flagged, k-means initialization will be skipped. \n\n");
  fprintf(stdout, "-1 [number of times for scheme 1 initialization], default is 0.\n\n");
  fprintf(stdout, "-2 [number of times for scheme 2 initialization], default is 0.\n\n");
  fprintf(stdout, "-r [integer as random seed for scheme 1 and 2 initialization], default is 0.\n\n");
  fprintf(stdout, "-s This is a flag. If not flagged, when performing search for block variable structure, more striction is imposed on \n");
  fprintf(stdout, "   the formation of the blocks. If flagged, the search range is expanded, and the search algorithm is that described \n");
  fprintf(stdout, "   in the paper.\n\n");
  fprintf(stdout, "-v This is a flag. If not flagged, non-diagonal covariance is assumed. If flagged, diagonal covariance.\n");
  fprintf(stdout, "-t This is a flag. If flagged, the final trained model will be printed on stdout.\n\n");
  fprintf(stdout, "----------------------------------------------------------------------\n");
}

int main(argc, argv)
     int argc;
     char *argv[];
{
  char infilename[300], mdfilename[300], bparfilename[300], parfilename[300], permfilename[300];
  FILE *infile, *mdfile, *bparfile, *parfile, *permfile;
  int i,j,k,m,n;
  int dim=2;
  double *dat;
  double **u;
  double *wt=NULL;
  int nseq, nb, *bdim, **var,  *numst;
  CondChain *md=NULL;
  double *loglikehd, lhsum;
  float epsilon=EPSILON;
  float tp1, tp2;
  int ninit0=1, ninit1=0, ninit2=0;
  int nperm=1,nperm0;
  int *Numst0, bparexist=0, parexist=0, permexist=0;
  int **vlist0=NULL;
  int maxdim=10, mindim=1, relaxsearch=0, randomseed=0;
  int No_nperm=1, printmodel=0;

  DIAGCOV=0;
  /*----------------------------------------------------------------*/
  /*---------------- Read in parameters from command line-----------*/
  /*----------------------------------------------------------------*/

  if (argc<=1) {
    printmanual();
    exit(0);
  }

  i = 1;
  while (i <argc)
    {
      if (*(argv[i]) != '-')
        {
          printf("**ERROR** bad arguments\n");
	  printf("To see manual, type trainmaster without arguments\n");
          exit(1);
        }
      else
        {
          switch(*(argv[i++] + 1))
            {
            case 'i':
              strcpy(infilename,argv[i]);
              break;
            case 'm':
              strcpy(mdfilename,argv[i]);
              break;
	    case 'p':
              strcpy(parfilename,argv[i]);
	      parexist=1;
	      break;
	    case 'b':
              strcpy(bparfilename,argv[i]);
	      bparexist=1;
	      break;
	    case 'o':
              strcpy(permfilename,argv[i]);
	      permexist=1;
	      break;
	    case 'e':
	      sscanf(argv[i],"%f",&epsilon);
	      break;
	    case 'd':
	      sscanf(argv[i],"%d",&dim);
	      break;
	    case 'n':
	      sscanf(argv[i],"%d",&nperm);
	      if (nperm<1) {
		fprintf(stderr, "Wrong number of variable permutations: %d\n",nperm);
		exit(1);
	      }
	      No_nperm=0;
	      break;
	    case 'x':
	      sscanf(argv[i],"%d",&maxdim);
	      break;
	    case '0':
	      ninit0=0;
	      i--;
	      break;
	    case '1':
	      sscanf(argv[i],"%d",&ninit1);
	      break;
	    case '2':
	      sscanf(argv[i],"%d",&ninit2);
	      break;
	    case 'r':
	      sscanf(argv[i],"%d",&randomseed);
	      break;
	    case 's':
	      relaxsearch=1; //if flagged, more flexible with the formulation of variable blocks
	      i--;
	      break;
	    case 'y':
	      mindim=2; //if flagged, more flexible with the formulation of variable blocks
	      i--;
	      break;
	    case 't':
	      printmodel=1; //if flagged, more flexible with the formulation of variable blocks
	      i--;
	      break;
	    case 'v':
	      DIAGCOV=1; //if flagged, more flexible with the formulation of variable blocks
	      i--;
	      break;
            default:
              {
                printf("**ERROR** bad arguments\n");
		printf("To see manual, type trainmaster without arguments\n");
                exit(1);
              }
            }
          i++;
        }
    }

  /*----------------------------------------------------------------*/
  /*--------------------- open files -------------------------------*/
  /*----------------------------------------------------------------*/
  
  infile = fopen(infilename, "r");
  if (infile == NULL)
    {
      printf("Couldn't open input data file \n");
      exit(1);
   }

  if (bparexist) {
    bparfile = fopen(bparfilename, "r");
    if (bparfile == NULL)
      {
	printf("Couldn't open input data file \n");
	exit(1);
      }
  }

  if (parexist) {
    parfile = fopen(parfilename, "r");
    if (parfile == NULL)
      {
	printf("Couldn't open input data file \n");
	exit(1);
      }
  }

  if (permexist) {
    permfile = fopen(permfilename, "r");
    if (permfile == NULL)
      {
	printf("Couldn't open input data file \n");
	exit(1);
      }
  } 
  
  mdfile = fopen(mdfilename, "w");
  if (mdfile == NULL)
    {
      printf("Couldn't open output model file \n");
      exit(1);
    }

  /*----------------------------------------------------------------*/
  /*----------------- Read in data ---------------------------------*/
  /*----------------------------------------------------------------*/

  if (bparexist) {
    fscanf(bparfile, "%d %d\n", &dim, &nb);
    bdim=(int *)calloc(nb,sizeof(int));
    numst=(int *)calloc(nb,sizeof(int));
    for (i=0;i<nb;i++)
      fscanf(bparfile, "%d", bdim+i);
    for (i=0;i<nb;i++)
      fscanf(bparfile, "%d", numst+i);
    
    var=(int **)calloc(nb,sizeof(int *));
    for (i=0;i<nb;i++) {
      var[i]=(int *)calloc(bdim[i],sizeof(int));
      for (j=0;j<bdim[i];j++) {
	fscanf(bparfile, "%d", var[i]+j);
	if (var[i][j]<0 || var[i][j]>=dim) {
	  fprintf(stderr, "Error in variables: %d, dim=%d\n",var[i][j],dim);
	  exit(1);
	}
      }
    }
  }

  nseq=0;
  while (!feof(infile)) {
    for (j=0;j<dim;j++) {
      m=fscanf(infile, "%e",&tp1);
    }
    nseq++;
    fscanf(infile, "\n");
  }
  rewind(infile);

  dat=(double *)calloc(nseq*dim,sizeof(double));
  u=(double **)calloc(nseq,sizeof(double *));
  for (i=0;i<nseq;i++) { u[i]=dat+i*dim;  }

  for (m=0;m<nseq;m++) {
    if (feof(infile)) {
      fprintf(stderr, "Error: not enough data in input file\n");
      exit(0);
    }
    for (j=0;j<dim;j++) {
      fscanf(infile, "%e",&tp1);
      dat[m*dim+j]=(double)tp1;
    }
    fscanf(infile, "\n");
  }

  fprintf(stderr, "Load in data: dim=%d, data size=%d\n",dim,nseq);

  if (parexist && bparexist==0) {//specify the number of components given the number of variables in a block
    Numst0=(int *)calloc(dim,sizeof(int));
    for (i=0;i<dim;i++) Numst0[i]=0;
    while (!feof(parfile)) {
      fscanf(parfile, "%d %d\n",&m,&n);
      if (m<=0 || m>dim) {
	fprintf(stderr, "Error in parameter file, block size exceeding dimension: %d %d\n",m,n);
      }
      Numst0[m-1]=n;
    }
    for (i=0;i<dim;i++) {
      if (Numst0[i]==0) {
	Numst0[i]=5+(i+1); //block size dimension plus 5
      }
    }
  } else {Numst0=NULL;}
  
  if (permexist && bparexist==0){
    nperm0=0;
    while (!feof(permfile)) {
      for (j=0;j<dim;j++) {
	fscanf(permfile, "%d",&m);
      }
      fscanf(permfile, "\n");
      nperm0++;
    }
    rewind(permfile);
    vlist0=(int **)calloc(nperm0,sizeof(int *));
    for (i=0;i<nperm0;i++) vlist0[i]=(int *)calloc(dim,sizeof(int));

    for (i=0;i<nperm0;i++){
      for (j=0;j<dim;j++) {
	fscanf(permfile, "%d",vlist0[i]+j);
	if (vlist0[i][j]<0 || vlist0[i][j]>=dim) {
	  fprintf(stderr, "Error variable dimension in permutation file: dim=%d, variable: %d\n",
		  dim, vlist0[i][j]);
	  exit(1);
	  }
      }
      fscanf(permfile, "\n");
    }
  } else {nperm0=0;}

  //Added 5/24/2017, properly set nperm and nperm0
  //If nperm is not specified in command line and nperm0>0, then use nperm0 for nperm
  if (No_nperm){
    if (nperm0>0) nperm=nperm0;
  }

  /*----------------------------------------------------------------*/
  /*----------------- Estimate HMM  ---------------------------------*/
  /*----------------------------------------------------------------*/
  
  loglikehd=(double *)calloc(nseq,sizeof(double));

  if (bparexist) {//variable block structure specified
    hmmfit_minit(u, nseq, nb, bdim, var, numst, &md, loglikehd, &lhsum, (double)epsilon, wt,
		 ninit0, ninit1, ninit2, randomseed); //lhsum is loglikelihood
    lhsum-=(double)(computenp(nb, bdim,numst))*log((double)nseq)*0.5; //BIC           
  }
  else {//variable block structure not given and will be searched
    hmmfit_vb(u, nseq, dim, &nb, &bdim, &var, nperm, nperm0, vlist0,
	      &md, loglikehd, &lhsum, (double)epsilon, wt, ninit0, ninit1,ninit2, randomseed,
	      Numst0, maxdim, mindim, relaxsearch); //output lhsum is BIC not loglikelihood
  }

  //Output the BIC value
  fprintf(stdout, "BIC of the model: %e\n", lhsum);

  //Output loglikehd from hmmfit() is not written out

  // Binary file for the output model
  write_ccm(md, mdfile);

  //Ascii file for the model
  if (printmodel) print_ccm(md,stdout); //debug

}
