#include "hmm.h"
#include <string.h>

int main(argc, argv)
     int argc;
     char *argv[];
{
  char infilename[100], mdfilename[100], outfilename[100];
  FILE *infile, *mdfile, *outfile;
  int i,j,k,m,n,noinfile=1;
  int dim=2;
  double *dat;
  double **u;
  double *wt=NULL,*merit,*meritbuf;
  int nseq=0, nb, *bdim, **var,  *numst, **optst, *intbuf, *cd, *cd2,*ct;
  CondChain *md=NULL;
  double *loglikehd, lhsum;
  float epsilon=EPSILON;
  float tp1, tp2;

  /*----------------------------------------------------------------*/
  /*---------------- Read in parameters from command line-----------*/
  /*----------------------------------------------------------------*/

  i = 1;
  while (i <argc)
    {
      if (*(argv[i]) != '-')
        {
          printf("**ERROR** bad arguments\n");
          exit(1);
        }
      else
        {
          switch(*(argv[i++] + 1))
            {
            case 'm':
              strcpy(mdfilename,argv[i]);
              break;
            case 'o':
              strcpy(outfilename,argv[i]);
              break;
            default:
              {
                printf("**ERROR** bad arguments\n");
                exit(1);
              }
            }
          i++;
        }
    }

  /*----------------------------------------------------------------*/
  /*--------------------- open files -------------------------------*/
  /*----------------------------------------------------------------*/
  
  mdfile = fopen(mdfilename, "r");
  if (mdfile == NULL)
    {
      printf("Couldn't open input model file \n");
      exit(1);
    }

  outfile = fopen(outfilename, "w");
  if (outfile == NULL)
    {
      printf("Couldn't open output model file \n");
      exit(1);
    }

  md=(CondChain *)calloc(1,sizeof(CondChain));
  readascii_ccm(md, mdfile);
  write_ccm(md,outfile);
  
  //For debug
  print_ccm(md,stdout);

}


